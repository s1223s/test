<?php
header('Content-Type:text/html;charset=utf8');
date_default_timezone_set('Asia/Shanghai');

$userid='11009';
$userkey='99f58aea0574d0bae3d31a20632d317f8e5bb13f';
?>
