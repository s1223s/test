<?php
$classFile = 'BCGpostnet.php';
$className = 'BCGpostnet';
$baseClassFile = 'BCGBarcode1D.php';
$codeVersion = '6.0.0';
